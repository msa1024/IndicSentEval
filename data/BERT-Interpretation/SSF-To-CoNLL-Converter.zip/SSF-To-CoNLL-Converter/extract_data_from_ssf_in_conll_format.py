# how to run the code
# author : Pruthwik Mishra, LTRC, IIIT-H
import ssfAPI as ssf
import os
import argparse
import re


def readFilesAndExtractSentencesInConLL(inputFolderPath, outputFolderPath, mergedFilePath, level=0):
    fileList = ssf.folderWalk(inputFolderPath)
    newFileList = []
    for fileName in fileList:
        xFileName = fileName.split('/')[-1]
        if xFileName == 'err.txt' or xFileName.split('.')[-1] in ['comments', 'bak'] or xFileName[:4] == 'task':
            continue
        else:
            newFileList.append(fileName)
#        newFileList = sorted(newFileList, key=lambda x: int(re.search('.*?-(\d+)-\d+', x[x.rfind('/') + 1:]).group(1)))
    newFileList = sorted(newFileList)
    print(newFileList)
    allSentences = list()
    for fileName in newFileList:
        d = ssf.Document(fileName)
        sentencesList = list()
        print(fileName)
        for tree in d.nodeList:
            print(tree.sentenceID)
            if level == 0:
                sentencesList.append('\n'.join([token for token in tree.generateSentence(
                ).split() if not re.search('^NUL', token)]) + '\n')
            elif level == 1:
                tokensWithPOS = [node.lex + '\t' + node.type.replace(
                    '__', '_') for chunkNode in tree.nodeList for node in chunkNode.nodeList if not re.search('^NUL', node.lex)]
                sentencesList.append('\n'.join(tokensWithPOS) + '\n')
            elif level == 2:
                tokensWithPOSMorph = [node.lex + '\t' + node.type.replace('__', '_') + '\t' + node.getAttribute(
                    'af') for chunkNode in tree.nodeList for node in chunkNode.nodeList if not re.search('^NUL', node.lex)]
                sentencesList.append('\n'.join(tokensWithPOSMorph) + '\n')
            else:
                tokenPOSAndChunk = list()
                for chunkNode in tree.nodeList:
                    for indexNode, node in enumerate(chunkNode.nodeList):
                        if indexNode == 0:
                            if not re.search('^NUL', node.lex):
                                tokenPOSAndChunk.append(
                                    node.lex + '\t' + node.type.replace('__', '_') + '\tB-' + chunkNode.type)
                        else:
                            if not re.search('^NUL', node.lex):
                                tokenPOSAndChunk.append(
                                    node.lex + '\t' + node.type.replace('__', '_') + '\tI-' + chunkNode.type)
                sentencesList.append('\n'.join(tokenPOSAndChunk) + '\n')
            outFilePath = os.path.join(
                outputFolderPath, fileName[fileName.rfind('/') + 1:])
            writeListToFile(sentencesList, outFilePath)
        else:
            allSentences += sentencesList
    # shuffle(allSentences)
    writeListToFile(allSentences, mergedFilePath)


def writeListToFile(dataList, outFilePath):
    with open(outFilePath, 'w', encoding='utf-8') as fileWrite:
        fileWrite.write('\n'.join(dataList) + '\n')
        fileWrite.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', dest='inp',
                        help="Add the input folder path")
    parser.add_argument('--output', dest='out',
                        help="Add the output folder path")
    parser.add_argument('--merge', dest='merge',
                        help="Add the merged file path")
    parser.add_argument('--level', dest='level',
                        help="Add the level 0: token, 1: token + pos, 2: token + pos + morph, 3 for token + pos + chunk", type=int, default=0)
    args = parser.parse_args()
    if not os.path.isdir(args.out):
        os.mkdir(args.out)
    readFilesAndExtractSentencesInConLL(
        args.inp, args.out, args.merge, args.level)
