How to run the code
- python extract_data_from_ssf_in_conll_format.py --input input_folder_path --output output_folder_path --merge merged_file_path --level level_of_extraction
- arguments
 - input_folder_path: the path containing SSF files
 - output_folder_path: the path where the extracted information will be stored in CoNLL format file wise
 - merged_file_path: merged file path contains all the all the file wise CoNLL information in a single file
 - level_of_extraction: 0 for token extraction, 1 for token+pos extraction, 2 for token+pos+morph, 3 for token+pos+chunk
